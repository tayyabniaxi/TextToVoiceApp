class AppFont {
  static const String robot = "Roboto-Medium";
}
