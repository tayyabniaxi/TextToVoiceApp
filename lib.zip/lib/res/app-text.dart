class AppText {
  static const String writePastText = "Write or Paste Text";
  static const String file = "Files";
  static const String gdrive = "GDriver";
  static const String pic = "Kindly";
  static const String email = "Gmail";
  static const String scan = "Scan text";
  static const String text = "Pdf & more";
  static const String link = "Web link";
  static const String scannedDes = "scanned document and images";
  static const String transformPdf = "Transform PDF & other file types";
  static const String convertUrlDes = "Convert URL to the page";
  static const String chatwithFileDes = "Transform chat with any file";
  static const String more = "Chat with AI";
  static const String failedToLoadItem = "Failed to load items";
  static const String ask_anything = "OR ask anything";
}
