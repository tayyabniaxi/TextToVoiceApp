abstract class SubscriptionEvent {}

class StartFreeTrial extends SubscriptionEvent {}

class UnlockYearlySubscription extends SubscriptionEvent {}

class CheckSubscriptionStatus extends SubscriptionEvent {}
