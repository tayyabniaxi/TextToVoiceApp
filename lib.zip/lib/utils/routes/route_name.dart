class RoutesName {
  static const String onboardingScreen = "OnboardingScreen";
  static const String bottomNavigationPage = "BottomNavigationPage";
  static const String PersonalDevelopmentScreeen = "PersonalDevelopmentScreeen";
}
