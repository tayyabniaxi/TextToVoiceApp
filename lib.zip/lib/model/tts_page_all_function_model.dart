// ignore_for_file: camel_case_types

import 'package:flutter/material.dart';

class AllFunctionModel {
  final String text;
  final String des;
  final String imageUrl;

  AllFunctionModel(
      {required this.text, required this.imageUrl, required this.des});
}
