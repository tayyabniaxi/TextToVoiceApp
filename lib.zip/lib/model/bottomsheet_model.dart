class BottomsheetModel {
  final String id;
  final String name;

  BottomsheetModel({required this.id, required this.name});
  
}
