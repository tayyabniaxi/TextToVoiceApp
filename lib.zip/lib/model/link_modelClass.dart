class LinkModel {
  final String url;
  final String title;

  LinkModel({required this.url, required this.title});
}
